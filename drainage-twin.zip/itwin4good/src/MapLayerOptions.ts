/*---------------------------------------------------------------------------------------------
* Copyright (c) Bentley Systems, Incorporated. All rights reserved.
* See LICENSE.md in the project root for license terms and full copyright notice.
*--------------------------------------------------------------------------------------------*/
import { MapLayerOptions, TileAdmin } from "@itwin/core-frontend";

// Sandbox provides map key values at runtime, however it's required to create your own account at map providers and
// get appropriate access tokens for your own projects (or exported Sandbox)
export const mapLayerOptions: MapLayerOptions = {
  // Api key for Bing Maps service. For more information https://www.microsoft.com/en-us/maps/create-a-bing-maps-key
  BingMaps: {
    key: "key",
    value: "Aqmoz31d_dWtqbryZoxesg_uEHXUHhzN8xlG_-mFRJFD1uNw7Zm7KbLYSbDXvp2c", // Era p eu botar isso em outro canto mas tudo bem
  },

  // Access token for Map Box service. For more information: https://docs.mapbox.com/help/getting-started/access-tokens
  MapboxImagery: {
    key: "access_token",
    value: "pk.eyJ1IjoiY2FuZGlkb2FsZmlsaG8iLCJhIjoiY2x4Nms2Yjl6MTFjajJpcTlzcW1vMHk3ZiJ9.LpGW4suICMUjLY1sCRdB7w",
  },
};

// Access token for Cesium service. For more information: https://cesium.com/learn/ion/cesium-ion-access-tokens
export const tileAdminOptions: TileAdmin.Props = {
  cesiumIonKey: "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJqdGkiOiI0MmE1MGQ2MC01NTQ5LTRkODMtOWU3Yi05N2ZhZmFjMWMxZjUiLCJpZCI6MjIxMDM0LCJpYXQiOjE3MTc4NzgxNzR9.ylOatzsXUu-kiREKAEmuEEjsF2EuyEYbCruGWQFH_lg",
};
